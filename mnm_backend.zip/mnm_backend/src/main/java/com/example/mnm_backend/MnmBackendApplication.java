package com.example.mnm_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MnmBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(MnmBackendApplication.class, args);
	}

}
