package com.example.mnm_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MnmBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
